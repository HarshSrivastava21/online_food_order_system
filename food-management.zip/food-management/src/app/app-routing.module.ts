


// // @NgModule({
// //     declarations : [NavbarComponent],
// //     imports : [RouterModule.forRoot(routes)],
    
// // })




// export class AppRoutingModule
// {

// }
// // export const routingComponents = [NavbarComponent]
